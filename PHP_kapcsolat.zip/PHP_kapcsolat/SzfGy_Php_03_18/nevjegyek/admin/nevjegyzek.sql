-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2021. Már 11. 10:55


--

--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `nevjegyek_1`
--

CREATE TABLE `nevjegyzek` (
  `id` int(11) NOT NULL,
  `nev` varchar(18) DEFAULT NULL,
  `cegnev` varchar(65) DEFAULT NULL,
  `foglalkozas` varchar(51) DEFAULT NULL,
  `mobil` varchar(28) DEFAULT NULL,
  `email` varchar(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `nevjegyzek`
--

INSERT INTO `nevjegyzek` (`id`, `nev`, `cegnev`, `foglalkozas`, `mobil`, `email`) VALUES
(1, 'Vörös János', 'Magyar Leszámítoló és Pénzváltó Bank', 'Szakács', 'j.voros@indamail.hu', '(20) 739-4059'),
(2, 'Balogh Januáriusz', 'Kanizsa Trend Kft.', 'Egyéb növénytermesztési és kertészeti foglalkozások', 'januariusz.balogh@gmail.com', '(20) 685-2286'),
(3, 'Pál Letícia', 'Salgótarjáni Öblösüveggyár', 'Egyéb funkcionális részegységek vezetői', 'pal.leticia@gmail.com', '(20) 422-7954'),
(4, 'Bognár Csanád', 'Rimai Coalitio', 'Bolti pénztáros', 'bognar.csanad@freemail.hu', '(70) 126-1342'),
(5, 'Katona Taksony', 'K&H Bank', 'Területi közig., igazságszolg. közép vezetője', 'taksony_katona@vipmail.hu', '(70) 668-3833'),
(6, 'Antal Ilona', 'Genesis Energy Nyrt.', 'Kereskedelmi részegység vezetője', 'antal.ilona@hotmail.com', '(20) 346-3148'),
(7, 'Barta Kristóf', 'NIK Központi Autótervező Iroda', 'Cipész, cipőkészítő, -javító', 'k.barta@gmail.com', '(30) 618-9109'),
(8, 'Orbán Anasztáz', 'HEINEKEN Hungária Sörgyárak Zrt.', 'Középfokú oktatási intézmény szakoktatója', 'anasztaz.orban@yahoo.com', '(20) 470-1547'),
(9, 'Kis Alex', 'Pécsi Dohánygyár', 'Vájár, segédvájár', 'kis_alex@gmail.com', '(30) 356-1144'),
(10, 'Nagy Aletta', 'Toti Sport', 'Bolti pénztáros', 'a.nagy@yahoo.com', '(70) 194-8179'),
(11, 'Nemes Eulália', 'Digic Pictures', 'Fegyveres erők felsőfokú foglalkozásai', 'eulalia_nemes@gmail.com', '(20) 907-7812'),
(12, 'Bakos Emil', 'Moskovits Sámuel vasöntödéje és gépgyára', 'Szállító- és rakodómunkás', 'bakos.emil@freemail.hu', '(30) 614-7177'),
(13, 'Kis Diána', 'Concorde Csoport', 'Egyéb műszaki foglalkozások', 'diana_kis@mailbox.hu', '(20) 425-8210'),
(14, 'Nagy Kelemen', 'Concorde Csoport', 'Egyéb szakképzett oktatók, nevelők', 'k.nagy@freemail.hu', '(20) 549-3060'),
(15, 'Horváth Margit', 'InfoRádió', 'Bútorasztalos', 'margit.horvath@hotmail.com', '(70) 531-6569'),
(16, 'Kiss Dénes', 'Goodwill Communications', 'Fegyveres erők felsőfokú foglalkozásai', 'denes_kiss@hotmail.com', '(30) 587-8352'),
(17, 'Szűcs Andrea', 'Offset és Játékkártya Nyomda Zrt.', 'Egyéb műszaki foglalkozások', 'andrea.szucs@freemail.hu', '(70) 218-2486'),
(18, 'Kocsis Krisztina', 'Dunai Vasmű', 'Szociális munkás', 'kocsis.krisztina@gmail.com', '(30) 582-3853'),
(19, 'Vincze János', 'Első Magyar Cérnagyár', 'Minőségi, műszaki, biztonsági ellenőr', 'vincze_janos@freemail.hu', '(20) 107-4404'),
(20, 'Hegedűs György', 'Cartographia', 'Általános orvos', 'gyorgy_hegedus@freemail.hu', '(30) 653-4082'),
(21, 'Molnár Jenő', 'Első Nemzeti Közműszolgáltató', 'Szövő', 'jeno.molnar@citromail.hu', '(20) 459-4843'),
(22, 'Sándor Apor', 'Nézőpont Intézet', 'Mosónő, vasalónő', 'sandor.apor@freemail.hu', '(70) 995-1103'),
(23, 'Halász Rozália', 'Merck', 'Hegesztő, lángvágó', 'rozalia.halasz@gmail.com', '(20) 766-7351'),
(24, 'Balla Ibolya', 'Centrum Áruházak', 'Kazángépkezelő (vizsgázott kazánfűtő)', 'balla.ibolya@gmail.com', '(20) 925-4219'),
(25, 'Szabó Virgínia', 'Raiffeisen Bank (Magyarország)', 'Felsőfokú tanintézeti tanár, oktató', 'v.szabo@yahoo.com', '(20) 915-5028'),
(26, 'Fekete Ferenc', 'Vidanet', 'Óvónő', 'fekete.ferenc@gmail.com', '(30) 976-6445'),
(27, 'Hegedűs Benedek', 'Index (internetes újság)', 'Számviteli és pénzügyi részegység vezetője', 'benedek_hegedus@freemail.hu', '(30) 682-1804'),
(28, 'Fodor Magdolna', 'Zoltán Hugó és Társa', 'Egyéb pedagógusok', 'magdolna_fodor@vipmail.hu', '(20) 751-8304'),
(29, 'Szűcs Gusztáv', 'T-Mobile (Magyar Telekom Csoport)', 'Mechanikai műszerész', 'szucs_gusztav@vipmail.hu', '(20) 213-1955'),
(30, 'Németh Taksony', 'Kner nyomda', 'Pénzügyi ügyintéző', 't.nemeth@hotmail.com', '(20) 626-9632'),
(31, 'Magyar Teodóra', 'Hajós- és Szántó Elektromos Gyára Rt.', 'Vegyészmérnök', 't.magyar@upc.hu', '(30) 634-9864'),
(32, 'Király Édua', 'HospInvest Zrt.', 'Oktatási részegység vezetője', 'edua.kiraly@hotmail.com', '(30) 569-2536'),
(33, 'Antal Félix', 'Virtual Call Center Solutions Zrt.', 'Középiskolai tanár, oktató', 'felix.antal@vipmail.hu', '(70) 843-4487'),
(34, 'Pintér Kartal', 'Pick Szeged Zrt.', 'Kereskedelmi részegység vezetője', 'pinter.kartal@yahoo.com', '(30) 411-8240'),
(35, 'Budai Frigyes', 'Magyar Turizmus Zrt.', 'Nehézföldmunkagép-kezelő', 'budai_frigyes@vipmail.hu', '(70) 438-5219'),
(36, 'Vincze Vazul', 'HospInvest Zrt.', 'Fegyveres erők felsőfokú foglalkozásai', 'vincze.vazul@gmail.com', '(20) 159-6994'),
(37, 'Farkas Damján', 'Raiffeisen Bank (Magyarország)', 'Egyéb termelői, szolg. részegységek vezetői', 'd.farkas@indamail.hu', '(30) 670-2868'),
(38, 'Sándor Xénia', 'Kinizsi Bank', 'Egészségügyi és szoc. szolg. részegység vezetője', 'xenia.sandor@freemail.hu', '(70) 718-7929'),
(39, 'Varga Viola', 'Elektronikus Mérőkészülékek Gyára (Sashalom)', 'Ügyvéd', 'v.varga@gmail.com', '(30) 132-3593'),
(40, 'Dudás Edgár', 'Minimal Art Family', 'Újságíró', 'edgar_dudas@gmail.com', '(20) 391-8580'),
(41, 'Horváth Hilária', 'Hungarotex', 'Fodrász, borbély', 'h.horvath@freemail.hu', '(30) 712-4304'),
(42, 'Kiss Lőrinc', 'Toti Sport', 'Általános orvos', 'kiss_lorinc@freemail.hu', '(30) 939-2149'),
(43, 'Barna Valter', 'Bárdi Autó Zrt.', 'Felszolgáló, vendéglátóipari eladó', 'barna_valter@vipmail.hu', '(30) 476-6957'),
(44, 'Balázs Ágoston', 'IFUA Horváth & Partners', 'Kereskedelmi kisszervezet vezetője', 'agoston.balazs@hotmail.com', '(30) 308-7837'),
(45, 'Szőke Egon', 'Dorogi hanglemezgyár', 'Fordító, tolmács', 'egon.szoke@gmail.com', '(70) 881-3975'),
(46, 'Kis Aida', 'CTnetwork', 'Számviteli és pénzügyi részegység vezetője', 'kis.aida@gmail.com', '(30) 758-4737'),
(47, 'Balog Flóra', 'FM1 Konzorcium', 'Ipari kisszervezet vezetője', 'balog.flora@freemail.hu', '(70) 179-3710'),
(48, 'Jakab Mária', 'Aegon Magyarország Pénztárszolgáltató Rt.', 'Fodrász, borbély', 'jakab.maria@yahoo.com', '(30) 423-1600'),
(49, 'Papp Tihamér', 'Murányi Unió', 'Bérelszámoló', 'papp_tihamer@freemail.hu', '(70) 518-7226'),
(50, 'Balázs Szeréna', 'Diósgyőri Gépgyár', 'Felsőfokú tanintézeti tanár, oktató', 'balazs.szerena@mailbox.hu', '(20) 885-1579'),
(51, 'Fábián Annamária', 'Nemzeti Infrastruktúra-fejlesztő Zrt.', 'Épületasztalos', 'a.fabian@indamail.hu', '(20) 649-1835'),
(52, 'Jakab Ulrika', 'Tarr Kft.', 'Szakasszisztens (orvosi)', 'jakab_ulrika@gmail.com', '(20) 939-3100'),
(53, 'Sándor Veronika', 'Dunai Vasmű', 'Erősáramú villamosmérnök', 'veronika_sandor@gmail.com', '(30) 377-6067'),
(54, 'Bogdán Bánk', 'MAL Magyar Alumínium Termelő és Kereskedelmi Zrt.', 'Kézi anyagmozgató, csomagoló', 'b.bogdan@gmail.com', '(30) 830-1382'),
(55, 'Pásztor Elizeus', 'ÁPISZ', 'Mechanikai műszerész', 'e.pasztor@yahoo.com', '(30) 756-7914'),
(56, 'Szabó Gergely', 'Dorogi hőerőmű', 'Általános iskolai tanár, tanító, oktató', 'g.szabo@freemail.hu', '(70) 783-5243'),
(57, 'Veres Aranka', 'Fehér Ferenc Precíziós Mechanikai és Gépműhelye', 'Egyéb szakképzett oktatók, nevelők', 'veres.aranka@freemail.hu', '(30) 707-4449'),
(58, 'Simon Brúnó', 'Auguszt Cukrászda', 'Kereskedelmi részegység vezetője', 'bruno_simon@gmail.com', '(70) 756-1051'),
(59, 'Boros Zakariás', 'Melléktermék- és Hulladékhasznosító Vállalat', 'Kézi anyagmozgató, csomagoló', 'zakarias_boros@mailbox.hu', '(70) 636-4264'),
(60, 'Farkas Tétény', 'IFUA Horváth & Partners', 'Háztömbfelügyelő, házfelügyelő, házgondnok', 'farkas.teteny@gmail.com', '(20) 440-1633'),
(61, 'Virág Dzsenifer', 'Vodafone', 'Szakasszisztens (orvosi)', 'dzsenifer.virag@freemail.hu', '(20) 937-9599'),
(62, 'Somogyi Cecília', 'ANY Biztonsági Nyomda', 'Oktatási szolgáltatási kisszervezet vezetője', 'c.somogyi@gmail.com', '(70) 187-3210'),
(63, 'Magyar Márta,Flóra', 'ProfiPower', 'Területi közig., igazságszolg. közép vezetője', 'm.magyar@hotmail.com', '(70) 906-8973'),
(64, 'Oláh Paula', 'Sanoma Budapest Zrt.', 'Egyéb növénytermesztési és kertészeti foglalkozások', 'olah.paula@yahoo.com', '(70) 647-6588'),
(65, 'Pataki Matilda', 'Globex Holding', 'Mosónő, vasalónő', 'pataki.matilda@gmail.com', '(20) 369-3664'),
(66, 'Boros Szaniszló', 'Petőfi Nyomda', 'Szakács', 'szaniszlo.boros@indamail.hu', '(70) 725-7827'),
(67, 'Orosz Egyed', 'Salgótarjáni Öblösüveggyár', 'Oktatási szolgáltatási kisszervezet vezetője', 'orosz_egyed@gmail.com', '(20) 988-2478'),
(68, 'Dudás Valentin', 'FŐTÁV Zrt.', 'Bér- és társadalombiztosítási ügyintéző', 'valentin.dudas@gmail.com', '(70) 485-4700'),
(69, 'Király Jusztina', 'Offset és Játékkártya Nyomda Zrt.', 'Gyógypedagógus', 'kiraly_jusztina@citromail.hu', '(30) 603-8769'),
(70, 'Balog Frigyes', 'MVM Magyar Villamos Művek Zrt.', 'Szakápoló', 'balog.frigyes@gmail.com', '(70) 586-9614'),
(71, 'Borbély Kunigunda', 'Telefongyár', 'Szállítási és raktározási részegység közv. term.ir.', 'k.borbely@yahoo.com', '(70) 270-9717'),
(72, 'Dudás Oszkár', 'Röck István Gépgyára', 'Iparművész', 'dudas.oszkar@vipmail.hu', '(20) 637-5737'),
(73, 'Deák Paulina', 'Auguszt Cukrászda', 'Egyéb irodai jellegű foglalkozások', 'p.deak@indamail.hu', '(70) 124-7532'),
(74, 'Fazekas Richárd', 'Miskolci Gőztéglagyár', 'Ipari részegység vezetője', 'r.fazekas@gmail.com', '(70) 494-6946'),
(75, 'Hajdú Valér', 'Magyar Pénzügyi Közvetítő Zrt.', 'Fegyveres erők felsőfokú foglalkozásai', 'valer.hajdu@freemail.hu', '(30) 650-3078'),
(76, 'Kozma Kartal', 'Moskovits Sámuel vasöntödéje és gépgyára', 'Építőipari részegység vezetője', 'kartal.kozma@yahoo.com', '(70) 559-2828'),
(77, 'Borbély Mária', 'Versys Clinics', 'Vezeték- és csőhálózat-szerelő', 'maria.borbely@mailbox.hu', '(30) 569-8800'),
(78, 'Budai Franciska', 'Herendi Porcelánmanufaktúra', 'Védőnő', 'budai_franciska@yahoo.com', '(30) 134-6204'),
(79, 'Halász Emánuel', 'Labor Műszeripari Művek', 'Egyéb magasan képzett ügyintézők', 'halasz_emanuel@mailbox.hu', '(70) 512-1472'),
(80, 'Virág Szilárd', 'K&H Bank', 'Egyéb magasan képzett ügyintézők', 'virag_szilard@gmail.com', '(70) 895-8552'),
(81, 'Hajdú Árpád', 'Zsolnay Porcelánmanufaktúra Zrt.', 'Szarvasmarhatartó és -tenyésztő', 'hajdu.arpad@gmail.com', '(20) 885-1150'),
(82, 'Bogdán Imre', 'Borsodi Sörgyár Zrt.', 'Fegyveres erők felsőfokú foglalkozásai', 'imre.bogdan@gmail.com', '(30) 887-6175'),
(83, 'Faragó Imelda', 'Pick Szeged Zrt.', 'Egyéb szakképzett oktatók, nevelők', 'i.farago@indamail.hu', '(70) 816-5736'),
(84, 'Tamás Filippa', 'Dorogi hőerőmű', 'Óvónő', 'tamas_filippa@hotmail.com', '(70) 846-6079'),
(85, 'Budai Gellért', 'Tartós állami tulajdonú társasági részesedéssel működő társaságok', 'Ipari kisszervezet vezetője', 'g.budai@citromail.hu', '(30) 832-3064'),
(86, 'Szilágyi Atanáz', 'MAL Magyar Alumínium Termelő és Kereskedelmi Zrt.', 'Szakorvos', 'szilagyi_atanaz@vipmail.hu', '(30) 333-6057'),
(87, 'Bogdán Botond', 'Invitel', 'Gyengeáramú villamosmérnök', 'bogdan.botond@gmail.com', '(30) 891-4250'),
(88, 'Szűcs Margit', 'MATERal', 'Fegyveres erők középfokú foglalkozásai', 'margit.szucs@yahoo.com', '(70) 187-6512'),
(89, 'Szőke Placida', 'Gyulaj Erdészeti és Vadászati Zrt.', 'Cipész, cipőkészítő, -javító', 'szoke.placida@freemail.hu', '(70) 661-2364'),
(90, 'Gál János', 'ELTE Idegennyelvi Továbbképző Központ', 'Szállító- és rakodómunkás', 'j.gal@freemail.hu', '(30) 198-4578'),
(91, 'Lengyel Izidor', 'Gamma (gyár)', 'Hegesztő, lángvágó', 'izidor_lengyel@gmail.com', '(30) 149-9353'),
(92, 'Németh Géza', 'Pécsi Bőrgyár', 'Postai kézbesítő', 'g.nemeth@gmail.com', '(30) 168-6167'),
(93, 'Hegedűs Péter', 'Buda-Cash Brókerház Zrt.', 'Piackutató, marketingtevékenységet végző', 'p.hegedus@hotmail.com', '(70) 673-9769'),
(94, 'Váradi Leó', 'Senior', 'Egészségügyi, oktatási szolgáltatási foglalkozások', 'l.varadi@gmail.com', '(30) 376-3507'),
(95, 'Vincze Vince', 'Budapesti Finomkötöttárugyár', 'Egyéb szakképzett oktatók, nevelők', 'vince_vincze@indamail.hu', '(30) 114-3636'),
(96, 'Fekete Eulália', 'REMIX Rádiótechnikai Vállalat', 'Ipari kisszervezet vezetője', 'eulalia.fekete@gmail.com', '(20) 212-7642'),
(97, 'Pásztor Apor', 'Melléktermék- és Hulladékhasznosító Vállalat', 'Egyéb fémmegmunkálók, felületkezelők', 'a.pasztor@gmail.com', '(30) 649-4540'),
(98, 'Oláh Emília', 'KDB Bank (Magyarország)', 'Mezőgazdasági vontatóvezető', 'olah.emilia@gmail.com', '(30) 660-4635'),
(99, 'Balla Léda', 'Első Magyar Koncessziós Autópálya Rt.', 'Egyszerű szolgáltatási jellegű foglalkozások', 'l.balla@vipmail.hu', '(30) 878-3177'),
(100, 'Hajdú Péter', 'Röck István Gépgyára', 'Egyéb növénytermesztési és kertészeti foglalkozások', 'p.hajdu@hotmail.com', '(30) 332-2332');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `nevjegyzek``
--
ALTER TABLE `nevjegyzek`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `nevjegyzek`
--
ALTER TABLE `nevjegyzek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
