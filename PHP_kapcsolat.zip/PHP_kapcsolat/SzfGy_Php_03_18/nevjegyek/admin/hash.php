<?php
$jelszo = "juliska";
print "<p><b>Jelszo:</b> {$jelszo}<br>";
print "<p><b>md5():</b> ".md5($jelszo)."<br>";
print "<p><b>sha1():</b> ".sha1($jelszo)."<p>";
?>