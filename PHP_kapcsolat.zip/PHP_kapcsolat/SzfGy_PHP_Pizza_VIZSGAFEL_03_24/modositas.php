<?php
require("../kapcsolat.php");

// Űrlap feldolgozása
if (isset($_POST['rendben'])) {

// Változók tisztítása
	
    $neve=strip_tags(trim($_POST['neve']));
	$rendelesideje = strip_tags(trim($_POST['rendelesideje']));
	$ara  = strip_tags(trim($_POST['ara']));
	$osszetetele  = strip_tags(strtolower(trim($_POST['osszetetele'])));

	// Változók vizsgálata
	if (empty($neve))
		$hibak[] = "Nem adtál meg nevet!";
	elseif (strlen($neve) < 3)
		$hibak[] = "Rossz nevet adtál meg!";
    if(empty($ara))
        $hibak[]="Nem adtál meg árat!";
	elseif (!empty($ara) && strlen($ara) < 2)
		$hibak[] = "Hibás árat adtál meg!";
    if(empty($rendelesideje))
        $hibak[] = "Nem adtál meg rendelési időt!";

	// Hibaüzenetet összeállítása
	if (isset($hibak)) {
		$kimenet = "<ul>\n";
		foreach($hibak as $hiba) {
			$kimenet.= "<li>{$hiba}</li>\n";
		}
		$kimenet.= "</ul>\n";
	}
	else {
		// Felvitel az adatbázisba
		$id = (int)$_POST['id'];
		$sql = "UPDATE pizzak
				SET neve = '{$neve}', rendelesideje = '{$rendelesideje}', ara = '{$ara}', osszetetele = '{$osszetetele}'
				WHERE id = {$id}";
		mysqli_query($dbconn, $sql);
		header("Location: lista.php");
	}
}

// Űrlap előzetes kitöltése
else {
	$id = (int)$_GET['id'];
	$sql = "SELECT *
			FROM pizzak
			WHERE id = {$id}";
	$eredmeny = mysqli_query($dbconn, $sql);
	$sor = mysqli_fetch_assoc($eredmeny);

	$neve    = $sor['neve'];
	$rendelesideje = $sor['rendelesideje'];
	$ara  = $sor['ara'];
	$osszetetele  = $sor['osszetetele'];
}
// Űrlap megjelenítése
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Módosítás</title>
<link href="../stilus.css" rel="stylesheet">
</head>

<body>
<h1>Rendelés módosítása</h1>
<form method="post" action="">
	<?php if (isset($kimenet)) print $kimenet; ?>
    <input type="hidden" id="id" name="id" value="<?php print $id; ?>">
	<p><label for="neve">Név*:</label><br>
	<input type="text" id="neve" name="neve" value="<?php if (isset($neve)) print $neve; ?>"></p>
	<p><label for="rendelesideje">Rendelés ideje*:</label><br>
	<input type="date" id="rendelesideje" name="rendelesideje" value="<?php if (isset($rendelesideje)) print $rendelesideje; ?>"></p>
	<p><label for="ara">Ára*:</label><br>
	<input type="number" id="ara" name="ara" value="<?php if (isset($ara)) print $ara; ?>"></p>
	<p><label for="osszetetele">Összetétele:</label><br>
	<input type="text" id="osszetetele" name="osszetetele" value="<?php if (isset($osszetetele)) print $osszetetele; ?>"></p>
	<p><em>A *-gal jelölt mezők kitöltése kötelező!</em></p>
	<input type="submit" id="rendben" name="rendben" value="Rendben">
	<input type="reset" value="Mégse">
	<p><a href="lista.php">Vissza a Rendelésekhez</a></p>
</form>
</body>
</html>