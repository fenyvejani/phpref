<?php
// régi kapcsolódás az adatbázishoz - ősmódszer, sokan használják ma is
/*@mysql_connect("localhost","root", "")  //server elérési út, felhasználó, jelszó @, nem írja ki, hogy elavúlt
//mysql_select_db("pizzak")  //adatbázis neve
//mysql_query("SET NAMES utf8")  //a kódolás legyen ...  */

//újabb meoldás
//mysqli_connect("localhost","root", "","pizzak") or die("Hiba az adatbázis csatlakozáskor") //itt már megadhatom az adatbázis nevét is


header("Content-Type: text/html; charset=utf-8");  //kimenet előállítása utf8-ra
define("DBHOST", "localhost");   //define - konstans definiálása (konstans neve, értéke)
define("DBUSER", "root");
define("DBPASS", "");
define("DBNAME", "pizzak");
$dbconn = @mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME) or die("Hiba az adatbázis csatlakozásakor!");
mysqli_query($dbconn, "SET NAMES utf8"); // ez után lehet kapcsolatot, lekérdezést intézni
?>