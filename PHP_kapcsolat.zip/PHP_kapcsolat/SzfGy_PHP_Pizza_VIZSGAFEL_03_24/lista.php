<?php
require("../kapcsolat.php");

$kifejezes = (isset($_POST['kifejezes'])) ? $_POST['kifejezes'] : "";
$sql = "SELECT *
		FROM pizzak
		WHERE (
			neve LIKE '%{$kifejezes}%'
			OR rendelesideje LIKE '%{$kifejezes}%'
			OR ara LIKE '%{$kifejezes}%'
			OR osszetetele LIKE '%{$kifejezes}%'
		)
		ORDER BY neve ASC";
$eredmeny = mysqli_query($dbconn, $sql);

$kimenet = "<table>
<tr>
	<th>Neve</th>
	<th>Rendelés Ideje</th>
	<th>Ára</th>
	<th>Összetétele</th>
	<th>Művelet</th>
</tr>";
while ($sor = mysqli_fetch_assoc($eredmeny)) {
	$kimenet.= "<tr>
		<td>{$sor['neve']}</td>
		<td>{$sor['rendelesideje']}</td>
		<td>{$sor['ara']}</td>
		<td>{$sor['osszetetele']}</td>
		<td><a href=\"torles.php?id={$sor['id']}\">Törlés</a> | <a href=\"modositas.php?id={$sor['id']}\">Módosítás</a></td>
	</tr>";
}
$kimenet.= "</table>";
?><!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Pizzarendelés</title>
<link href="stilus.css" rel="stylesheet">
</head>

<body>
<img src="logo.jpg" alt="logo">
<h1>Pizzarendelés</h1>

<form method="post" action="">
	<input type="search" id="kifejezes" name="kifejezes">
</form>
<p><a href="felvitel.php">Rendelés felvétele</a></p>
<?php print $kimenet; ?>
<p><a href="felvitel.php">Rendelés felvétele</a></p>
</body>
</html>