-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2020. Máj 25. 08:37
-- Kiszolgáló verziója: 10.4.11-MariaDB
-- PHP verzió: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `pizzak`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pizzak`
--

CREATE TABLE `pizzak` (
  `id` int(11) NOT NULL,
  `neve` varchar(45) COLLATE utf8_hungarian_ci NOT NULL,
  `rendelesideje` date NOT NULL,
  `ara` int(30) NOT NULL,
  `osszetetele` varchar(80) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `pizzak`
--

INSERT INTO `pizzak` (`id`, `neve`, `rendelesideje`, `ara`, `osszetetele`) VALUES
(1, 'Margherita', '2018-04-01', 1900, 'Friss paradicsom,\r\nfriss mozzarella,\r\nfriss bazsalikom'),
(2, 'Formaggio', '2018-04-01', 2490, 'Négy sajt (mozza-\r\nrella, parmezán,\r\n\r\npecorino, jarlsberg)'),
(3, 'Parma', '2018-04-03', 1250, 'Friss paradicsom,\r\nmozzarella, parma,\r\nszalonna, friss rucula'),
(4, 'margaréta', '2020-05-26', 900, 'szósz, sajt'),
(5, 'margaréta', '2020-05-04', 900, 'szósz, sajt'),
(6, 'kukoricás', '2020-05-10', 1200, 'kukorica, sajt, szósz'),
(7, 'kukoricás', '2020-05-27', 1200, 'kukorica, sajt, szósz'),
(8, 'vegetáriánus', '2020-05-11', 1500, 'szósz, kukorica, gomba, zöldborsó, sajt'),
(9, 'vegetáriánus', '2020-05-19', 1500, 'szósz, kukorica, gomba, zöldborsó, sajt'),
(10, 'kedvenc', '2020-05-03', 989, 'szósz, gomba,sajt, sonka'),
(11, 'kedvenc', '2020-05-12', 989, 'szósz, gomba,sajt, sonka');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `pizzak`
--
ALTER TABLE `pizzak`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `pizzak`
--
ALTER TABLE `pizzak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
