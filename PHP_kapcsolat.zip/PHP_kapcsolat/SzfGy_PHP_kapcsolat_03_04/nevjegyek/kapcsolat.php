<?php
    // @ mert régebbi parancs, megoldás
    /*@mysql_connect("localhost","root") // szerver elérési útja,felhasználóneve
    mysql_select_db("kezdo")
    mysql_query("SET NAME utf8")*/

    // egy másik megoldás
    //mysqli_connect("localhost","root","","kezdo") or die ("hiba");

    // harmadik megoldás
    header("Content-Type: text/html; charset=utf-8");
    // define - konstans deklarálás // konstanstok, ha valami változik csak átírom
    define("DBHOST","localhost");
    define("DBUSER","root");
    define("DBPASS","");
    define("DBNAME","kezdo");
    $dbconn=@mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
    mysqli_query($dbconn,"SET NAME utf8");
?>